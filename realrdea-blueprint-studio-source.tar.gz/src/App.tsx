import BlueprintBuilder from './pages/BlueprintBuilder';

export default function App() {
  return <BlueprintBuilder />;
}
