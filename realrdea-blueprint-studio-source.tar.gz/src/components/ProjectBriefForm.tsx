import { FileText, RotateCcw } from 'lucide-react';
import { Input } from '@project/components/ui/input';
import { Label } from '@project/components/ui/label';
import { Textarea } from '@project/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@project/components/ui/select';
import type { ProjectBrief, Platform } from '../lib/blueprint';

type Props = { value: ProjectBrief; onChange: (value: ProjectBrief) => void; onReset: () => void };

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return <div className="space-y-2"><Label className="text-sm font-medium">{label}</Label>{children}{hint && <p className="text-xs leading-relaxed text-muted-foreground">{hint}</p>}</div>;
}

export default function ProjectBriefForm({ value, onChange, onReset }: Props) {
  const set = (key: keyof ProjectBrief, next: string) => onChange({ ...value, [key]: next });
  const textarea = (key: keyof ProjectBrief, placeholder: string, rows = 3) => (
    <Textarea value={value[key]} onChange={(e) => set(key, e.target.value)} placeholder={placeholder} rows={rows} className="resize-y border-border bg-background/80" />
  );
  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3">
        <div><div className="mb-1 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-accent"><FileText className="h-3.5 w-3.5" />Project brief</div><p className="text-sm text-muted-foreground">A few details make the generated plan yours.</p></div>
        <button onClick={onReset} type="button" className="inline-flex items-center gap-1.5 rounded-sm px-2 py-1.5 text-xs text-muted-foreground hover:bg-muted hover:text-foreground"><RotateCcw className="h-3.5 w-3.5" />Reset</button>
      </div>
      <Field label="Project name"><Input value={value.name} onChange={(e) => set('name', e.target.value)} placeholder="e.g. Neighbourhood Notes" className="border-border bg-background/80" /></Field>
      <Field label="What are you building?"><Select value={value.platform} onValueChange={(v) => set('platform', v as Platform)}><SelectTrigger className="border-border bg-background/80"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Website">Website</SelectItem><SelectItem value="Mobile app">Mobile app</SelectItem><SelectItem value="Video game">Video game</SelectItem></SelectContent></Select></Field>
      <Field label="Who is it for?" hint="Name the people and what they need.">{textarea('audience', 'Freelancers who need a simpler way to track invoices')}</Field>
      <Field label="Describe the idea" hint="What problem does it solve? What should feel better afterward?">{textarea('idea', 'A simple way to…')}</Field>
      <Field label="Must-have features" hint="One per line works well.">{textarea('features', 'Create a project\nSee progress at a glance\nExport a summary', 4)}</Field>
      <Field label="Visual direction">{textarea('visualDirection', 'Editorial, calm, friendly, premium…', 2)}</Field>
      <Field label="Colors or brand notes">{textarea('palette', 'Warm cream, ink black, a restrained terracotta accent…', 2)}</Field>
      <Field label="Special needs or constraints" hint="Include tools, accessibility, privacy, offline needs, assets, or what to avoid.">{textarea('specialNeeds', 'e.g. keyboard accessible; no sign-in for the first release', 3)}</Field>
    </div>
  );
}
