import { useState } from 'react';
import { Check, Clipboard, Download, FileText, FileText as BuildIcon } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@project/components/ui/tabs';
import { Button } from '@project/components/ui/button';
import type { Artifact } from '../lib/blueprint';
import { toast } from 'sonner';

type Props = { artifacts: Artifact[] };

function saveFile(name: string, text: string) {
  const blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name; a.click(); URL.revokeObjectURL(url);
}

export default function GeneratedArtifacts({ artifacts }: Props) {
  const [active, setActive] = useState(artifacts[0].id);
  const [copied, setCopied] = useState(false);
  const selected = artifacts.find((a) => a.id === active) ?? artifacts[0];
  const copy = async () => {
    try { await navigator.clipboard.writeText(selected.content); setCopied(true); toast.success('Copied to clipboard'); window.setTimeout(() => setCopied(false), 1600); }
    catch { toast.error('Clipboard access was blocked. Select and copy the text instead.'); }
  };
  const download = () => {
    saveFile('realrdea-project-blueprint.md', artifacts.map((a) => `# ${a.title}\n\n${a.content}`).join('\n\n---\n\n'));
    toast.success('Blueprint downloaded');
  };
  return (
    <section className="overflow-hidden rounded-sm border border-border bg-card shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border px-5 py-4 md:px-7">
        <div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-sm bg-accent/10 text-accent"><BuildIcon className="h-4 w-4" /></div><div><p className="font-serif text-xl">Your blueprint</p><p className="text-xs text-muted-foreground">Generated instantly on this device</p></div></div>
        <div className="flex gap-2"><Button variant="outline" size="sm" onClick={copy} className="gap-2">{copied ? <Check className="h-4 w-4" /> : <Clipboard className="h-4 w-4" />}{copied ? 'Copied' : 'Copy section'}</Button><Button size="sm" onClick={download} className="gap-2"><Download className="h-4 w-4" /><span className="hidden sm:inline">Download all</span><span className="sm:hidden">Download</span></Button></div>
      </div>
      <Tabs value={active} onValueChange={setActive} className="w-full">
        <div className="overflow-x-auto border-b border-border px-4 md:px-6"><TabsList className="h-12 min-w-max justify-start gap-1 rounded-none bg-transparent p-0">{artifacts.map((a) => <TabsTrigger key={a.id} value={a.id} className="h-12 rounded-none border-b-2 border-transparent px-3 text-xs data-[state=active]:border-accent data-[state=active]:bg-transparent data-[state=active]:text-foreground">{a.title}</TabsTrigger>)}</TabsList></div>
        {artifacts.map((a) => <TabsContent key={a.id} value={a.id} className="m-0 p-5 md:p-7"><div className="mb-4 flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.15em] text-accent"><FileText className="h-3.5 w-3.5" />{a.eyebrow}</div><pre className="max-h-[540px] overflow-auto whitespace-pre-wrap break-words rounded-sm border border-border bg-background/70 p-4 font-sans text-[13px] leading-6 text-foreground/85 md:p-6">{a.content}</pre></TabsContent>)}
      </Tabs>
      <div className="border-t border-border bg-muted/40 px-5 py-3 text-xs leading-relaxed text-muted-foreground md:px-7">This tool formats a project brief—it does not call AI, build code, create media, or remove the limits of other platforms. Copy the prompt into an AI tool you choose.</div>
    </section>
  );
}
